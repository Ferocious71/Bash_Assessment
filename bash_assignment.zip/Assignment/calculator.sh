#!/bin/bash

read -p "Enter first number: " num1

# Check if num1 is a valid integer
if [[ "$num1" =~ ^-?[0-9]+$ ]]; then
	:
else
    echo "Error: $num1 is not a valid number. Please enter a number."
    exit 1
fi

read -p "Enter Second number: " num2
# Check if num2 is a valid integer
if [[ "$num2" =~ ^-?[0-9]+$ ]]; then
	:
else
    echo "Error: $num2 is not a valid number. Please enter a number."
    exit 1
fi

read -p "Enter the opeartor you want to perform (+,-,*,/,%) - " oprt

if [[ $oprt == "+" ]];then
	echo "Addition = $(($num1+$num2))"

elif [[ $oprt == "-" ]];then
	echo "Subtraction = $(($num1-$num2))"
	
elif [[ $oprt == "*" ]];then
	echo "Multiplication = $(($num1*$num2))"

elif [[ $oprt == "/" ]];then
	echo "Division = $(($num1/$num2))"

elif [[ $oprt == "%" ]];then
	echo "Modulus = $(($num1%$num2))"
	
else
	echo -e "\nWrong Operator Selected"
	
fi