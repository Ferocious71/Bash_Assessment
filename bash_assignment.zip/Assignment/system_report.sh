#!/bin/bash

# Output file
REPORT_FILE="system_report.txt"

# Function to get system uptime
get_uptime() {
    echo "System Uptime:"
    uptime
    echo ""
}

# Function to get memory usage
get_memory_usage() {
    echo "Memory Usage:"
    free -h
    echo ""
}

# Function to get CPU load
get_cpu_load() {
    echo "CPU Load:"
    top -bn1 | grep "load average:" | awk '{printf "Load Average: %.2f, %.2f, %.2f\n", $(NF-2), $(NF-1), $NF}'
    echo ""
}

# Function to get disk usage
get_disk_usage() {
    echo "Disk Usage:"
    df -h
    echo ""
}

# Function to get running processes
get_running_processes() {
    echo "Running Processes:"
    ps -e --format pid,cmd,%mem,%cpu --sort=-%mem | head -n 10
    echo ""
}

# Write the report to a file
echo "Generating system information report..."

{
    echo "System Information Report - $(date)"
    echo "================================="
    get_uptime
    get_memory_usage
    get_cpu_load
    get_disk_usage
    get_running_processes
} > "$REPORT_FILE"

echo "Report saved to $REPORT_FILE"
