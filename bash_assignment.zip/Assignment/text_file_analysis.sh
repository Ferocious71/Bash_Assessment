#!/bin/bash

# Check if a file argument is provided
if [ $# -eq 0 ]; then
    echo "No Argument Provided"
    exit 1
fi

# Assign the first argument to a variable
FILE=$1

# Check if the file exists and is a regular file
if [ ! -f "$FILE" ]; then
    echo "Error: File '$FILE' not found!"
    exit 1
fi

# Use 'wc' to count lines, words, and characters
LINES=$(wc -l < "$FILE")
WORDS=$(wc -w < "$FILE")
CHARS=$(wc -m < "$FILE")

# Display the results
echo "Lines: $LINES"
echo "Words: $WORDS"
echo "Characters: $CHARS"
