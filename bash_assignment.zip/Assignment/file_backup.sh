#!/bin/bash

# Check if a directory argument is provided
if [ $# -eq 0 ]; then
    echo "Usage: $0 <directory>"
    exit 1
fi

# Assign the first argument to a variable (the target directory)
SOURCE_DIR=$1

# Check if the directory exists
if [ ! -d "$SOURCE_DIR" ]; then
    echo "Error: Directory '$SOURCE_DIR' not found!"
    exit 1
fi

# Create a timestamp for the backup directory
TIMESTAMP=$(date +"%Y%m%d_%H%M%S")
BACKUP_DIR="backup_$TIMESTAMP"

# Create the backup directory
mkdir -p "$BACKUP_DIR"

# Copy all .txt files from the source directory to the backup directory
find "$SOURCE_DIR" -maxdepth 1 -type f -name "*.txt" -exec cp {} "$BACKUP_DIR" \;

# Confirm the backup
if [ "$(ls -A $BACKUP_DIR)" ]; then
    echo "Backup complete. Files copied to $BACKUP_DIR"
else
    echo "No .txt files found in $SOURCE_DIR"
    rmdir "$BACKUP_DIR" # Remove the empty backup directory if no files were copied
fi
