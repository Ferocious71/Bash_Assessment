#!/bin/bash

# Configuration
PROCESS_NAME="nginx"  
LOG_FILE="/var/log/process_nginx_monitor.log"  # Log file location
TIMESTAMP=$(date +"%Y-%m-%d %H:%M:%S")

# Function to log actions
log_action() {
    local message=$1
    echo "$TIMESTAMP - $message" >> "$LOG_FILE"
}

# Check if the process is running
if pgrep "$PROCESS_NAME" > /dev/null
then
    echo "$PROCESS_NAME is running."
    log_action "$PROCESS_NAME is running."
else
    echo "$PROCESS_NAME is not running, starting the process..."
    log_action "$PROCESS_NAME was not running. Starting $PROCESS_NAME."

    # Attempt to start the process
    sudo systemctl "$PROCESS_NAME" start

    # Verify if the process started successfully
    if pgrep "$PROCESS_NAME" > /dev/null
    then
        log_action "$PROCESS_NAME started successfully."
    else
        log_action "Failed to start $PROCESS_NAME."
    fi
fi
