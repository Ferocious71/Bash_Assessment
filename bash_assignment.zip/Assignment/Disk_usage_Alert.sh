#!/bin/bash

# Configuration
THRESHOLD=80
ADMIN_EMAIL="salmanmuneeb@gmail.com" 
SUBJECT="Disk Space Warning: Root Filesystem"
MAIL_CMD=$(which mail) # Ensure 'mail' command is installed

# Function to send email alert
send_email_alert() {
    local usage=$1
    local body="Warning: The root filesystem disk usage is at ${usage}%. Please take action."
    echo "$body" | $MAIL_CMD -s "$SUBJECT" "$ADMIN_EMAIL"
}

# Get the disk usage percentage for the root filesystem
# 'df' command output, fetch the percentage value (e.g., 85%)
USAGE=$(df / --output=pcent | tail -n 1 | tr -dc '0-9')

# Check if disk usage is greater than the threshold
if [ "$USAGE" -gt "$THRESHOLD" ]; then
    echo "Disk usage is above $THRESHOLD%. Sending email alert..."
    send_email_alert "$USAGE"
else
    echo "Disk usage is under control: ${USAGE}%."
fi
