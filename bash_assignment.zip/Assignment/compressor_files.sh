#!/bin/bash

#Write a script that compresses the `/home/user/documents` directory into a tarball named `documents_backup.tar.gz` and moves it to the `/home/user/backup` directory. This script should be scheduled to run daily using cron.<<'


# Define variables for source and destination
SOURCE_DIR="/home/user/documents"
BACKUP_DIR="/home/user/backup"
BACKUP_FILE="documents_backup.tar.gz"

# Create the backup directory if it does not exist and giving permission to it.
sudo mkdir -p "$BACKUP_DIR"
sudo chmod 777 $BACKUP_DIR

# Create a compressed tarball of the documents directory
tar -czf "$BACKUP_DIR/$BACKUP_FILE" -C "$SOURCE_DIR" .

# Optional: Print a message indicating the backup was successful
echo "Backup of "$SOURCE_DIR" completed successfully at $(date)." >> "$BACKUP_DIR/backup_log.txt"


#Open the crontab file for editing:
#crontab -e

#Add the following line to schedule the script to run daily at, for example, 1:10 AM
#10 1 * * * /bin/bash /home/bash_sample/Assignment/compressor_files.sh