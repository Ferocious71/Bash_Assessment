#!/bin/bash

# Check if a file argument is provided
if [ $# -ne 1 ]; then
    echo "No Argument Provided"
    exit 1
fi

file="$1"

# Check if the specified file exists
if [ ! -e "$file" ]; then
    echo "Error: File '$file' does not exist."
    exit 1
fi

# Check permissions
echo "Checking permissions for file: $file"

# Check read permission
if [ -r "$file" ]; then
    echo -e "\nRead permission: Granted"
else
    echo "Read permission: Denied"
fi

# Check write permission
if [ -w "$file" ]; then
    echo "Write permission: Granted"
else
    echo "Write permission: Denied"
fi

# Check execute permission
if [ -x "$file" ]; then
    echo "Execute permission: Granted"
else
    echo "Execute permission: Denied"
fi


