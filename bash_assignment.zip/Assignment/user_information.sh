#!/bin/bash

# Get the username
username=$(whoami)

# Get the user ID and group ID
user_id=$(id -u)
group_id=$(id -g)


# Get the home directory and shell being used
home_dir=$HOME
shell_used=$SHELL


# Display the information

echo "User Information:"
echo "-----------------"
echo "Username: 	 $username"
echo "User id:     	 $user_id"
echo "Group id:  	 $group_id"
echo "Home Directory:  $home_dir"
echo "Shell Used:      $shell_used"

