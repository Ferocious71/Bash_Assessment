#!/bin/bash

# goes to home directory
cd /home

#creates a directory named user under /home/user directory
sudo mkdir user

#creates a directory named proects under /home/user directory and giving permissions to it
sudo mkdir projects
sudo chmod 777 project1

cd projects
#inside projects directory, create 3 more directories and giving permissions to it
sudo mkdir project1
sudo mkdir project2
sudo mkdir project3

sudo chmod +x project1
sudo chmod +x project1
sudo chmod +x project1

#coming out from projects directory
cd ..

#create a directory under /home/user directory named douments and giving permissions to it
sudo mkdir documents
sudo chmod 777 documents/

#create a directory under /home/user directory named downloads and giving permissions to it
sudo mkdir downloads
sudo chmod +x downloads/


